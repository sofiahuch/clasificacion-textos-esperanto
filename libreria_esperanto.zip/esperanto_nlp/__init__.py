from .nlp import Doc, Token, nlp, tokenizar, lematizar_palabra, etiquetar_pos, es_stopword, palabras_relevantes
