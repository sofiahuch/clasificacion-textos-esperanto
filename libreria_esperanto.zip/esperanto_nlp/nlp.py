
import re
import json
import requests

PATRON_TOKEN = re.compile(
    r"[A-Za-zĈĉĜĝĤĥĴĵŜŝŬŭ]+|[0-9]+|[^\w\s]",
    flags=re.UNICODE
)

URL_STOPWORDS = (
    "https://raw.githubusercontent.com/"
    "jparisu/nlp-esperantilo/main/resources/esperanto/vortoj.json"
)

STOPWORDS_RESPALDO = {
    "la", "kaj", "de", "en", "al", "por", "kun", "pri", "pro",
    "ĉe", "el", "per", "sen", "sur", "sub", "inter", "ĝis",
    "mi", "vi", "li", "ŝi", "ĝi", "ni", "ili", "oni", "si",
    "estas", "estis", "estos", "estu", "ke", "sed", "aŭ",
    "se", "ĉar", "kiel", "kiu", "tio", "ĉi", "ne"
}

def _extraer_palabras(objeto):
    palabras = set()
    if isinstance(objeto, str):
        palabras.add(objeto.casefold())
    elif isinstance(objeto, list):
        for elemento in objeto:
            palabras.update(_extraer_palabras(elemento))
    elif isinstance(objeto, dict):
        for valor in objeto.values():
            palabras.update(_extraer_palabras(valor))
    return palabras

def _cargar_stopwords():
    try:
        respuesta = requests.get(URL_STOPWORDS, timeout=10)
        respuesta.raise_for_status()
        palabras = _extraer_palabras(respuesta.json())
        if palabras:
            return palabras
    except (requests.RequestException, ValueError):
        pass
    return STOPWORDS_RESPALDO.copy()

STOPWORDS = _cargar_stopwords()

def tokenizar(texto):
    if not isinstance(texto, str):
        raise TypeError("El texto debe ser una cadena.")
    return PATRON_TOKEN.findall(texto)

def es_stopword(palabra):
    return palabra.casefold() in STOPWORDS

def _quitar_flexion(palabra):
    resultado = palabra.casefold()
    if resultado.endswith("n") and len(resultado) > 1:
        resultado = resultado[:-1]
    if resultado.endswith("j") and len(resultado) > 1:
        resultado = resultado[:-1]
    return resultado

def lematizar_palabra(palabra):
    base = _quitar_flexion(palabra)
    for terminacion in ("as", "is", "os", "us", "u"):
        if base.endswith(terminacion) and len(base) > len(terminacion):
            return base[:-len(terminacion)] + "i"
    return base

ARTICULOS = {"la"}
PRONOMBRES = {
    "mi", "vi", "li", "ŝi", "ĝi", "ni", "ili", "oni", "si",
    "ĉi", "tiu", "kio", "kiu", "ĉio", "neniu"
}
PREPOSICIONES = {
    "al", "anstataŭ", "antaŭ", "apud", "ĉe", "ĉirkaŭ", "da",
    "de", "dum", "ekster", "el", "en", "ĝis", "inter", "je",
    "kontraŭ", "krom", "kun", "laŭ", "malantaŭ", "malgraŭ",
    "per", "po", "por", "post", "preter", "pri", "pro", "sen",
    "sub", "super", "sur", "tra", "trans"
}
CONJUNCIONES = {"kaj", "aŭ", "sed", "nek", "do"}
ADVERBIOS_COMUNES = {"ne", "jes", "tre", "ankoraŭ", "jam", "nur", "ankaŭ"}

def etiquetar_pos(palabra):
    palabra = palabra.casefold()
    if palabra in ARTICULOS:
        return "DET"
    if palabra in PRONOMBRES:
        return "PRON"
    if palabra in PREPOSICIONES:
        return "ADP"
    if palabra in CONJUNCIONES:
        return "CCONJ"
    if palabra in ADVERBIOS_COMUNES:
        return "ADV"
    base = _quitar_flexion(palabra)
    if base.endswith("o"):
        return "NOUN"
    if base.endswith("a"):
        return "ADJ"
    if base.endswith("e"):
        return "ADV"
    if base.endswith(("i", "as", "is", "os", "us", "u")):
        return "VERB"
    if palabra.isdigit():
        return "NUM"
    if re.fullmatch(r"[^\w\s]", palabra, flags=re.UNICODE):
        return "PUNCT"
    return "X"

class Token:
    def __init__(self, texto):
        self.text = texto
        self.lemma_ = lematizar_palabra(texto)
        self.pos_ = etiquetar_pos(texto)
        self.is_stop = es_stopword(texto)

    def __repr__(self):
        return (
            f"Token(text={self.text!r}, lemma_={self.lemma_!r}, "
            f"pos_={self.pos_!r}, is_stop={self.is_stop})"
        )

class Doc:
    def __init__(self, texto):
        self.text = texto
        self.tokens = [Token(p) for p in tokenizar(texto)]

    def __iter__(self):
        return iter(self.tokens)

    def __len__(self):
        return len(self.tokens)

    def __getitem__(self, posicion):
        return self.tokens[posicion]

def nlp(texto):
    return Doc(texto)

def palabras_relevantes(doc):
    return [
        token.lemma_ for token in doc
        if not token.is_stop and token.pos_ != "PUNCT"
    ]
