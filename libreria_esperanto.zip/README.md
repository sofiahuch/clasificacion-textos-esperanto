# Esperanto NLP

Librería propia de NLP basada en reglas para Esperanto.

Incluye tokenización, lematización aproximada, POS-tagging, stopwords y objetos Doc/Token.

No utiliza spaCy, NLTK ni Stanza.

## Uso

```python
from esperanto_nlp import nlp
doc = nlp('La bela robo estas nova.')
for token in doc:
    print(token.text, token.lemma_, token.pos_, token.is_stop)
```
